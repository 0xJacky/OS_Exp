//
//  writer.h
//  Process-Readers-and-Writers
//
//  Created by Jacky on 2020/12/10.
//

#ifndef writer_h
#define writer_h

#include <stdio.h>

void *writerThread(void *arg);

#endif
