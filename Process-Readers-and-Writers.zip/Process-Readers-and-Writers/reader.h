//
//  reader.h
//  Process-Readers-and-Writers
//
//  Created by Jacky on 2020/12/10.
//

#ifndef reader_h
#define reader_h

#include <stdio.h>

void *readerThread(void *arg);

#endif
